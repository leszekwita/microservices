package com.radzik.michal.shop.statistic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StatisticApplicationTests {

	@Test
	void contextLoads() {
	}

}
