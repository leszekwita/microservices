package com.radzik.michal.shop.notyfication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotyficationApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotyficationApplication.class, args);
	}

}
