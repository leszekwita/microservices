package com.radzik.michal.shop.notyfication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotyficationApplicationTests {

	@Test
	void contextLoads() {
	}

}
